import "./Footer.css"

const Footer = () => {
    return (
        <footer>
            <p> @MernStack 2024 </p>
        </footer>
    )
}

export default Footer;